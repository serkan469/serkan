﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RentACarProje
{


    public abstract class Tasit
    {
        public string Id { get; set; }
        public string Marka { get; set; }
        public string Model { get; set; }
        public string Tur { get; set; }
    

private double _gunlukUcret;
        public double GunlukUcret
        {
            get { return _gunlukUcret; }
            set
            {
                if (value < 0)
                    throw new Exception("Günlük ücret negatif olamaz!");
                _gunlukUcret = value;
            }
        }
        private string _plaka;
        public string Plaka
        {
            get { return _plaka; }
            set
            {
                if (string.IsNullOrEmpty(value)) throw new Exception("Plaka boş geçilemez!");
                _plaka = value.ToUpper(); 
            }
        }
        public abstract double FiyatHesapla(int gunSayisi);
    } 
}