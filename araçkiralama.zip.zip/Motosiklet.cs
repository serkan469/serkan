﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RentACarProje
{
    public class Motosiklet : Tasit
    {
        public bool KaskDahilMi { get; set; }

        // POLİMORFİZM 
        public override double FiyatHesapla(int gunSayisi)
        {
            
            double normalFiyat = gunSayisi * GunlukUcret;
            return normalFiyat * 0.80;
        }
    } 
}