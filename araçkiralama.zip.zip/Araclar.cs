﻿using System;

namespace AracKiralamaProjesi
{
    public abstract class Arac
    {
        
        private string plaka;
        private string marka;
        private string model;
        private int yil;
        private decimal gunlukUcret;
        private bool kiradaMi;

        // KONTOLLÜ ERİŞİM

        public string Plaka
        {
            get { return plaka; }
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                    throw new Exception("Plaka boş olamaz.");
                plaka = value;
            }
        }

        public string Marka
        {
            get { return marka; }
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                    throw new Exception("Marka boş olamaz.");
                marka = value;
            }
        }

        public string Model
        {
            get { return model; }
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                    throw new Exception("Model boş olamaz.");
                model = value;
            }
        }

        public int Yil
        {
            get { return yil; }
            set
            {
                if (value < 1990 || value > DateTime.Now.Year)
                    throw new Exception("Geçersiz üretim yılı.");
                yil = value;
            }
        }

        public decimal GunlukUcret
        {
            get { return gunlukUcret; }
            set
            {
                if (value <= 0)
                    throw new Exception("Günlük ücret 0'dan büyük olmalıdır.");
                gunlukUcret = value;
            }
        }

        public bool KiradaMi
        {
            get { return kiradaMi; }
            set { kiradaMi = value; }
        }

        
        public abstract string AracTuruGetir();

        
        public decimal ToplamTutarHesapla(int gunSayisi)
        {
            if (gunSayisi <= 0)
                throw new Exception("Gün sayısı 0'dan büyük olmalıdır.");

            return gunSayisi * gunlukUcret;
        }
    }

    //  KALITIM  POLİMORFİZM
    public class Otomobil : Arac
    {
        private string vitesTuru;
        private string yakitTuru;

        public string VitesTuru
        {
            get { return vitesTuru; }
            set { vitesTuru = value; }
        }

        public string YakitTuru
        {
            get { return yakitTuru; }
            set { yakitTuru = value; }
        }

        //  POLİMORFİZM
        public override string AracTuruGetir()
        {
            return "Binek Otomobil";
        }
    }
}
