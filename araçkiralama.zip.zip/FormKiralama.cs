﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RentACarProje
{
    public partial class FormKiralama : Form
    {
        public FormKiralama()
        {
            InitializeComponent();
        }

        private async void btnHesapla_Click(object sender, EventArgs e)
        {
            string plaka = txtPlakaGir.Text;
            int gun = Convert.ToInt32(txtGunSayisi.Text);
            string tur = rbArabaSec.Checked ? "Araba" : "Motosiklet";

            FirebaseManager manager = new FirebaseManager();

            
            Tasit arananTasit = await manager.TekAracGetir(plaka, tur);

            if (arananTasit != null)
            {
                
                // Kod aynı ama davranış farklı! (Polimorfizm)

                double tutar = arananTasit.FiyatHesapla(gun);

                lblSonuc.Text = "Toplam Tutar: " + tutar.ToString("C2");

                if (arananTasit is Motosiklet)
                    MessageBox.Show("motosiklet indirimi uygulandı!");
            }
            else
            {
                MessageBox.Show("Araç bulunamadı!");
            }
        }

        private void FormKiralama_Load(object sender, EventArgs e)
        {

        }
    }
}
