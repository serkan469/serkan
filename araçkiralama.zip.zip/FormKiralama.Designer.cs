﻿namespace RentACarProje
{
    partial class FormKiralama
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtPlakaGir = new System.Windows.Forms.TextBox();
            this.txtGunSayisi = new System.Windows.Forms.TextBox();
            this.lblSonuc = new System.Windows.Forms.Label();
            this.rbArabaSec = new System.Windows.Forms.RadioButton();
            this.rbMotorSec = new System.Windows.Forms.RadioButton();
            this.btnHesapla = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtPlakaGir
            // 
            this.txtPlakaGir.Location = new System.Drawing.Point(348, 228);
            this.txtPlakaGir.Name = "txtPlakaGir";
            this.txtPlakaGir.Size = new System.Drawing.Size(100, 22);
            this.txtPlakaGir.TabIndex = 0;
            // 
            // txtGunSayisi
            // 
            this.txtGunSayisi.Location = new System.Drawing.Point(348, 200);
            this.txtGunSayisi.Name = "txtGunSayisi";
            this.txtGunSayisi.Size = new System.Drawing.Size(100, 22);
            this.txtGunSayisi.TabIndex = 1;
            // 
            // lblSonuc
            // 
            this.lblSonuc.Font = new System.Drawing.Font("Stencil", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSonuc.ForeColor = System.Drawing.SystemColors.Highlight;
            this.lblSonuc.Location = new System.Drawing.Point(263, 310);
            this.lblSonuc.Name = "lblSonuc";
            this.lblSonuc.Size = new System.Drawing.Size(267, 54);
            this.lblSonuc.TabIndex = 2;
            this.lblSonuc.Text = "TOPLAM TUTAR:0.00 TL";
            this.lblSonuc.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // rbArabaSec
            // 
            this.rbArabaSec.AutoSize = true;
            this.rbArabaSec.Location = new System.Drawing.Point(453, 267);
            this.rbArabaSec.Name = "rbArabaSec";
            this.rbArabaSec.Size = new System.Drawing.Size(65, 20);
            this.rbArabaSec.TabIndex = 3;
            this.rbArabaSec.TabStop = true;
            this.rbArabaSec.Text = "Araba";
            this.rbArabaSec.UseVisualStyleBackColor = true;
            // 
            // rbMotorSec
            // 
            this.rbMotorSec.AutoSize = true;
            this.rbMotorSec.Location = new System.Drawing.Point(348, 267);
            this.rbMotorSec.Name = "rbMotorSec";
            this.rbMotorSec.Size = new System.Drawing.Size(89, 20);
            this.rbMotorSec.TabIndex = 4;
            this.rbMotorSec.TabStop = true;
            this.rbMotorSec.Text = "Motosiklet";
            this.rbMotorSec.UseVisualStyleBackColor = true;
            // 
            // btnHesapla
            // 
            this.btnHesapla.Location = new System.Drawing.Point(337, 378);
            this.btnHesapla.Name = "btnHesapla";
            this.btnHesapla.Size = new System.Drawing.Size(117, 30);
            this.btnHesapla.TabIndex = 5;
            this.btnHesapla.Text = "Fiyatı hesapla";
            this.btnHesapla.UseVisualStyleBackColor = true;
            this.btnHesapla.Click += new System.EventHandler(this.btnHesapla_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(175, 231);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(155, 16);
            this.label1.TabIndex = 6;
            this.label1.Text = "Kiralanacak araç plakası";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(265, 269);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 16);
            this.label2.TabIndex = 7;
            this.label2.Text = "Araç Türü";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(261, 203);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(69, 16);
            this.label3.TabIndex = 8;
            this.label3.Text = "Gün sayısı";
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label4.Font = new System.Drawing.Font("Rockwell", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(-17, -5);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(819, 93);
            this.label4.TabIndex = 9;
            this.label4.Text = "Kiralama Yap";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // FormKiralama
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnHesapla);
            this.Controls.Add(this.rbMotorSec);
            this.Controls.Add(this.rbArabaSec);
            this.Controls.Add(this.lblSonuc);
            this.Controls.Add(this.txtGunSayisi);
            this.Controls.Add(this.txtPlakaGir);
            this.Name = "FormKiralama";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FormKiralama";
            this.Load += new System.EventHandler(this.FormKiralama_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtPlakaGir;
        private System.Windows.Forms.TextBox txtGunSayisi;
        private System.Windows.Forms.Label lblSonuc;
        private System.Windows.Forms.RadioButton rbArabaSec;
        private System.Windows.Forms.RadioButton rbMotorSec;
        private System.Windows.Forms.Button btnHesapla;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
    }
}