﻿using FireSharp.Config;
using FireSharp.Interfaces;
using FireSharp.Response;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections.Generic;
using System.IO;

namespace RentACarProje
{
    // SOYUTLAMA
    public interface IFirebaseIslemleri
    {
        Task AracEkle(Tasit tasit);
        Task<Dictionary<string, Araba>> ArabaGetir();
    }

    public class FirebaseManager : IFirebaseIslemleri
    {
        
        IFirebaseConfig config = new FirebaseConfig
        {
            AuthSecret = "jCtW29zbMJddgu6ad5xFEuyC4iP8rXmtDiZD7fOT",
            BasePath = "https://odev-f8837-default-rtdb.firebaseio.com/"
        };
        IFirebaseClient client;

        public FirebaseManager()
        {
            client = new FireSharp.FirebaseClient(config);
        }

        public async Task AracEkle(Tasit tasit)
        {
          
            await client.SetAsync("Araclar/" + tasit.Plaka, tasit);
        }

        public async Task<Dictionary<string, Araba>> ArabaGetir()
        {
            
            FirebaseResponse response = await client.GetAsync("Araclar");
            if (response.Body == "null") return null;
            return response.ResultAs<Dictionary<string, Araba>>();
        }

        
        public async Task<Tasit> TekAracGetir(string plaka, string tur)
        {
            FirebaseResponse response = await client.GetAsync("Araclar/" + plaka);
            if (tur == "Araba")
                return response.ResultAs<Araba>();
            else
                return response.ResultAs<Motosiklet>();
        }
    }
}
