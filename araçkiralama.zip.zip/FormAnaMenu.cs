﻿using System;
using System.Windows.Forms;

namespace RentACarProje
{
    
    public partial class FormAnaMenu : Form    //KALITIM
    {
        public FormAnaMenu()
        {
            InitializeComponent();
        }

     
        private void btnEkle_Click(object sender, EventArgs e)
        {
            FormAracEkle frm = new FormAracEkle();
            frm.Show(); 
            
        }

        
        private void btnListele_Click(object sender, EventArgs e)
        {
            FormAracListele frm = new FormAracListele();
            frm.Show();
        }

       
        private void btnKiralama_Click(object sender, EventArgs e)
        {
            FormKiralama frm = new FormKiralama();
            frm.Show();
        }

       
        private void btnCikis_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        
        private void FormAnaMenu_Load(object sender, EventArgs e)
        {
            
        }
    }
}