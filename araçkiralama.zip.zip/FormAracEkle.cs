﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AracKiralamaProjesi;

namespace RentACarProje
{
    public partial class FormAracEkle : Form
    {
        public FormAracEkle()
        {
            InitializeComponent();
        }

        private async void btnKaydet_Click(object sender, EventArgs e)
        {
            Otomobil yeniArac = new Otomobil();
            try
            {
                Tasit yeniTasit = null; // Polimorfizm

                if (rbAraba.Checked)
                {
                    yeniTasit = new Araba();
                    yeniTasit.Tur = "Araba";
                }
                else if (rbMotosiklet.Checked)
                {
                    yeniTasit = new Motosiklet();
                    yeniTasit.Tur = "Motosiklet";
                }
                else
                {
                    MessageBox.Show("Lütfen araç türü seçin!");
                    return;
                }


                yeniTasit.Plaka = txtPlaka.Text; 
                yeniTasit.Marka = txtMarka.Text;
                yeniTasit.Model = txtModel.Text;
                yeniTasit.GunlukUcret = Convert.ToDouble(txtUcret.Text); // Kapsülleme

                FirebaseManager manager = new FirebaseManager();
                await manager.AracEkle(yeniTasit);

                MessageBox.Show("Araç Eklendi!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);

            }

        }

        private void FormAracEkle_Load(object sender, EventArgs e)
        {

        }
    }
}
    

