﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RentACarProje
{
  public class Araba : Tasit
    {
        public int KapiSayisi { get; set; } 

        // POLİMORFİZM
        public override double FiyatHesapla(int gunSayisi)
        {
            
            return gunSayisi * GunlukUcret;
        }






    }
}
