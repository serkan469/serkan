﻿using System;
using System.Windows.Forms;

namespace RentACarProje
{
    public partial class FormLogin : Form
    {
        public FormLogin()
        {
            InitializeComponent();
        }

        private void btnGiris_Click(object sender, EventArgs e)
        {
          
            if (txtKadi.Text == "admin" && txtSifre.Text == "admin")
            {
                FormAnaMenu anaMenu = new FormAnaMenu();
                anaMenu.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Kullanıcı adı veya şifre hatalı!", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

     

        
    }
}