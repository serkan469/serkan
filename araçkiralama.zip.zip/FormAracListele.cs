﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RentACarProje
{
    public partial class FormAracListele : Form
    {
        public FormAracListele()
        {
            InitializeComponent();
        }

        private async void btnListele_Click(object sender, EventArgs e)
        {
            FirebaseManager manager = new FirebaseManager();
            var veriler = await manager.ArabaGetir(); 

            if (veriler != null)
            {
                dataGridView1.DataSource = veriler.Values.ToList();
            }
            else
            {
                MessageBox.Show("Veri yok.");
            }
        }

        private void FormAracListele_Load(object sender, EventArgs e)
        {

        }
    }
}
